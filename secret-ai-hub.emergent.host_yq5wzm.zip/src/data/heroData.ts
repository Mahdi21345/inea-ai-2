export const heroData = {
  badge: 'EXCLUSIVE ACCESS'
} as const;
