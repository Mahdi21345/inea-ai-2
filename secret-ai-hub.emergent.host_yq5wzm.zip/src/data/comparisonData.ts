export const comparisonData = {
  falsePromises: [
    'Mysterious "Dark GPT" applications that don\'t exist',
    'Dangerous pirated software for your security',
    'Promises of impossible gains without work',
    'Access to "forbidden" AIs (pure marketing invention)',
    'Complex solutions requiring technical skills'
  ],
  realSolution: [
    'A scientifically designed and tested prompt collection',
    'Access methods for multiple AI platforms',
    'Simple method: copy-paste the proven prompts',
    'Works with various legal AI services',
    'Clear instructions for optimal results'
  ]
} as const;
