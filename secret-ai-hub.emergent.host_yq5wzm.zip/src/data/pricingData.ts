export const pricingFeatures = [
  'Complete secret prompt arsenal (not just one prompt)',
  'Lifetime access to all prompts',
  'Prompts for multiple AI platforms (not just INEA AI)',
  'Weekly new prompts and updates',
  'Referral system ($10 per referral)',
  '24/7 support access',
  'Business idea generator prompts',
  'Productivity and efficiency prompts',
  'Personal development and learning prompts',
  'Email delivery of all access details'
] as const;
